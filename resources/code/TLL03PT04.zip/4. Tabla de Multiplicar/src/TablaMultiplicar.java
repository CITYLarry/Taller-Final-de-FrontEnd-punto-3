import java.util.Scanner;

public class TablaMultiplicar {

	public static void main(String[] args) {

		Scanner in = new Scanner(System.in);
		System.out.println("Ingrese el número de la tabla de multiplicar: ");
		int tabla = in.nextInt();
		in.close();
		
		for (int i = 1; i <= 10; i++) {
			int resultado = tabla * i;
			System.out.println(i + " x " + tabla + " = " + resultado);
		}// End for

	}// End method main

}// End class TablaMultiplicar
