
public class Matriz {

	public static void main(String[] args) {
		
		String arr[][] = new String[4][5];
		
		// Fisrst line
		arr[0][0] = "01";
		arr[0][1] = "02";
		arr[0][2] = "03";
		arr[0][3] = "04";
		arr[0][4] = "05";
		
		// Second line
		arr[1][0] = "06";
		arr[1][1] = "07";
		arr[1][2] = "08";
		arr[1][3] = "09";
		arr[1][4] = "10";
		
		// Third line
		arr[2][0] = "11";
		arr[2][1] = "12";
		arr[2][2] = "13";
		arr[2][3] = "14";
		arr[2][4] = "15";
		
		// Fourth line
		arr[3][0] = "16";
		arr[3][1] = "17";
		arr[3][2] = "18";
		arr[3][3] = "19";
		arr[3][4] = "20";
		
		for (int i = 0; i < 4; i++) {
			
			if (i % 2 == 0) {
				for (int j = 0; j < 5; j++) {
					System.out.print(arr[i][j] + " ");
				}// End for
				System.out.println();
			}else {
				for (int j = 4; j >= 0 ; j--) {
					System.out.print(arr[i][j] + " ");
				}// End for
				System.out.println();
			}// End ifelse
					
		}// End for
		
	}// End method main
	
}// End class Matriz
