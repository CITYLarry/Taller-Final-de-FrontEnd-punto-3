import java.util.Scanner;

public class Party {

	public static void main(String[] args) {
		
		Scanner in = new Scanner(System.in);
		
		System.out.println("Escriba su nombre: ");
		String firtsName = in.next();
		
		System.out.println("Escriba su apellido: ");
		String lastName = in.next();
		
		System.out.println("Escriba su edad: ");
		int age = in.nextInt();
		
		in.close();
		
		if (age >= 18) {
			System.out.println(firtsName +  " " + lastName + 
							   " usted es mayor de edad, por lo tanto puede entrar a la fiesta.");
		} else {
			System.out.println(firtsName +  " " + lastName +
					" usted es menor de edad, por lo tanto, no puede entrar a la fiesta, por favor devuélvase a su casa.");
		}

	}// End method main

}// End class Party
