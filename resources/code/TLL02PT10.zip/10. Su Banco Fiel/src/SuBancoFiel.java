import java.util.Scanner;

public class SuBancoFiel {

	public static void main(String[] args) {
		
		int amount;
		
		Scanner in = new Scanner(System.in);
		
		System.out.println("-----------------------------------\n" +
						   "Crear cuenta bancaria Su Banco Fiel\n" +
						   "-----------------------------------\n" +
						   "Nombre del titular: ");
		String owner = in.next();
		System.out.println("Cantidad a depositar: ");
		amount = in.nextInt();
		
		if (amount < 0) {
			System.out.println("Valor introducido no valido");
		} else {
			System.out.println("Sr(a). " + owner + ", ¿qué acción desea realizar con su producto?\n" +
					   		   "1. Nuevo ingreso.\n" +
					   		   "2. Nuevo retiro\n" +
					   		   "3. Consultar saldo\n" +
					   		   "4. Salir.");
			int option = in.nextInt();
			switch (option) {
				case 1:{
					amount = ingreso(amount, in, owner);
					break;
				}// End case 1
				case 2:{
					amount = retiro(amount, in, owner);
					break;
				}// End case 2
				case 3:{
					consulta(amount, owner);
					break;
				}// End case 3
				case 4:{
					System.out.println("Sesion cerrada con exito.");
					break;
				}// End case 4
				default:{
					System.out.println("Opción invalida.");
				}// End default
			}// End switch		
		}// End if else
		in.close();
	}// End method main

	public static int ingreso(int amount, Scanner in, String owner) {
		System.out.println("-------------\n" +
		   		   		   "Nuevo ingreso\n" +
		   		   		   "-------------\n" +
						   "¿Cuanto desea depositar?: ");
		int cash = in.nextInt();
		
		if (cash < 0) {
			System.out.println("Valor introducido no valido.");
		} else {
			amount = amount + cash;
			System.out.println("Sr(a)." + owner + ", con su deposito de: " + cash + 
							   ", su nuevo saldo es de " + amount);
		}// End if else
		return amount;
	}// End method ingreso
	
	public static int retiro(int amount, Scanner in, String owner) {
		System.out.println("-------------\n" +
		   		   		   "Nuevo retiro\n" +
		   		   		   "-------------\n" +
						   "¿Cuanto desea retirar?: ");
		int cash = in.nextInt();
		
		if (cash >= amount && cash < 0) {
			System.out.println("Valor introducido no valido.");
		} else {
			amount = amount - cash;
			System.out.println("Sr(a)." + owner + ", con su retiro de: " + cash + 
							   ", su nuevo saldo es de " + amount);
		}// End if else
		return amount;
	}// End method ingreso
	
	public static void consulta(int amount, String owner) {
		System.out.println("-----------------\n" +
		   		   		   "Consulta de saldo\n" +
		   		   		   "-----------------\n" +
						   "Sr(a)." + owner + ", su saldo disponible es de " + amount + ".");
	}// End method consulta
	
}// End class SuBancoFiel
