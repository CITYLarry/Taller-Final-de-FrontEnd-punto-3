import java.util.Scanner;

public class MiSalud {

	public static void main(String[] args) {
	
	// Variables
	String product;
	String comment;
		
	// Prints the menu
	System.out.println("----------------------\n" +
					   "Seleccione el producto\n" +
					   "----------------------\n" +
					   "1. Acetaminoden.\n" + 
					   "2. Dolex.\n" + 
					   "3. Curitas.\n" + 
					   "4. Alcohol.\n" + 
					   "5. Condones.\n" +
					   "6. Devolver producto\n" +
					   "7. Salir.\n");
	Scanner in = new Scanner(System.in);
	int option = in.nextInt();
	
	switch (option) {
	case 1:{
		System.out.println("------------\n" +
				   		   "Acetaminofen\n" +
				   		   "------------\n" +
				   		   "Precio x10: $2.000\n" +
				   		   "\n" +
				   		   "Descripción: \n" +
				   		   "El acetaminofen se usa para aliviar el dolor leve o moderado de las cefaleas, dolores musculares, períodos menstruales, resfriados, y los dolores de garganta, , muelas, espalda, así como de las reacciones a las vacunas (inyecciones) y para reducir la fiebre. El acetaminofen también se puede usar para aliviar el dolor de la osteoartritis (artritis causada por la ruptura del revestimiento de las articulaciones). El acetaminofen pertenece a una clase de medicamentos llamados analgésicos y antipiréticos (reductores de la fiebre). Su acción consiste en cambiar la manera en que el cuerpo responde al dolor.\n" +
				   		   "\n");
		buy();		   		   
		break;
	}// End case 1
	case 2:{
		System.out.println("-----\n" +
				   		   "Dolex\n" +
				   		   "-----\n" +
				   		   "Precio x24: $22.650\n" +
				   		   "\n" +
				   		   "Descripción: \n" +
				   		   "Dolex Analgésico, Alivio del dolor y la fiebre con rápida acción, suave con su estómago, Tabletas recubiertas.\n" +
				   		   "\n");
		buy();		   		   
		break;
	}// End case 2
	case 3:{
		System.out.println("-------\n" +
				   		   "Curitas\n" +
				   		   "-------\n" +
				   		   "Precio x18: $12.900\n" +
				   		   "\n" +
				   		   "Descripción: \n" +
				   		   "Antiadherente estéril no tejida.\n" +
				   		   "\n");
		buy();		   		   
		break;
	}// End case 3
	case 4:{
		System.out.println("-------\n" +
				   		   "Alcohol\n" +
				   		   "-------\n" +
				   		   "Precio x18: $6.850\n" +
				   		   "\n" +
				   		   "Descripción: \n" +
				   		   "Aprovecha todos los beneficios desinfectantes del alcohol.\n" +
				   		   "\n");
		buy();		   		   
		break;
	}// End case 4
	case 5:{
		System.out.println("--------\n" +
				   		   "Condones\n" +
				   		   "--------\n" +
				   		   "Precio x18: $9.050\n" +
				   		   "\n" +
				   		   "Descripción: \n" +
				   		   "Condón lubricado con superficie lisa y elástica para una sensación natural.\n" +
				   		   "\n");
		buy();		   		   
		break;
	}// End case 5
	case 6:{
		System.out.println("Producto a devolver: ");
		product = in.next();
		
		System.out.println("Razón de devolución: ");
		comment = in.next();
		break;
	}// End case 6
	case 7:{
		System.out.println("Hasta luego, vuelva pronto!");
		break;
	}
	default:
		System.out.println("Opción invalida.");
		break;
	}// End switch
	
	in.close();

	}// End method main

	public static void buy() {
		
		Scanner sc = new Scanner(System.in);
		System.out.println("¿Desea comprar? (y/n)");
		String buyed = sc.next();
		sc.close();
		
		if (buyed.equals("y")) {
			System.out.println("¡Gracias por su compra!");
		} else {
			System.out.println("No se realizó compra.");
		}// End if else
		
	}// End method buy
	
}// End class MiSalud
