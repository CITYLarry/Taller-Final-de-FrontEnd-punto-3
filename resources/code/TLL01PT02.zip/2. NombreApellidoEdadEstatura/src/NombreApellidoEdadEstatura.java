import java.util.Scanner;

public class NombreApellidoEdadEstatura {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		System.out.println("Escriba su nombre: ");
		String firstName = sc.next();

		System.out.println("Escriba su apellido: ");
		String lastName = sc.next();

		System.out.println("Escriba su edad: ");
		int age = sc.nextInt();

		System.out.println("Escriba su altura: ");
		double height = sc.nextDouble();

		sc.close();

	}// End method main

}// End class NombreApellidoEdadEstatura
