import java.util.Scanner;

public class AreaCalculator {

	public static void main(String[] args) {
		
		double a,b, area;
		
		Scanner in = new Scanner(System.in);
		
		System.out.println("------------------------------\n" +
				   		   "Seleccione una opción del menú\n" +
				   		   "------------------------------\n" +
				   		   "1. Área de un rectangulo.\n" +
				   		   "2. Área de un triangulo.\n" +
				   		   "3. Área de un trapecio.\n" +
				   		   "4. Salir.");
		int option = in.nextInt();
		
		switch (option){
		case 1:{
			System.out.println("---------------------\n" +
			   		   		   "Área de un rectangulo\n" +
			   		   		   "---------------------\n");
			a = getA(in);
			b = getB(in);
			
			area = a * b;
			System.out.println("El area del rectangulo es: " + area);
			break;
		}// End case 1
		case 2:{
			System.out.println("--------------------\n" +
			   		   		   "Área de un triángulo\n" +
			   		   		   "--------------------\n");
			a = getA(in);
			b = getB(in);
			
			area = (a * b)/ 2;
			System.out.println("El area del triángulo es: " + area);
			break;
		}// End case 2
		case 3:{
			System.out.println("--------------------\n" +
			   		   		   "Área de un triapecio\n" +
			   		   		   "--------------------\n");
			a = getA(in);
			b = getB(in);
			
			System.out.println("Base 2: ");
			double b2 = in.nextDouble();
			
			area = ((b + b2)/ 2) * a;
			System.out.println("El area del trapecio es: " + area);
			break;
		}// End case 3
		case 4:{
			System.out.println("Adios!");
		}// End case 4
		default:{
			System.out.println("Opción invalida.");
		}// End default case
		}// End switch
		
	}// End method main
	
public static double getA(Scanner in) {
	System.out.println("Altura: \n");
	double a = in.nextDouble();
	return a;
}// End method getA

public static double getB(Scanner in) {
	System.out.println("Altura: \n");
	double b = in.nextDouble();
	return b;
}// End method getB

}// End class AreaCalculator
