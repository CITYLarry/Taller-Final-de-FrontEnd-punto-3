
public class CicloMientras {

	public static void main(String[] args) {
		
		int i = 0;
		int j = 9;
		String a = "          ";
		String b = "*";
		 
		while (i < 10) {
			System.out.print(a);
			a = a.substring(0, j);
			System.out.println(b);
			b = b + "*";
			i++;
			j--;
		}// End while

	}// End method main

}// End class CicloMientras
