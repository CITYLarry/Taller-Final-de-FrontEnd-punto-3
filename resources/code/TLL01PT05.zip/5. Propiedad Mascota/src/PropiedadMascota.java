import java.util.Scanner;

public class PropiedadMascota {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Escriba el nombre de su mascota: ");
		String petName = sc.next();

		System.out.println("Escriba la edad de su mascota: ");
		int petAge = sc.nextInt();
		
		System.out.println("Escriba la especie de su mascota: ");
		String petSpecies = sc.next();
		
		System.out.println("Escriba el nombre del propietario: ");
		String owner = sc.next();

		sc.close();
		
		System.out.println(petName + " es un(a) " + petSpecies + 
						   " el cual, tiene " + petAge + " años de edad y " +
						   owner + " es actualmente su dueño(a).");

	}// End method main

}// End class PropiedadMascota
