import java.util.Scanner;

public class SecretariaSaludMunicipal {

	public static void main(String[] args) {
		
		Scanner in = new Scanner(System.in);
		
		System.out.println("------------------\n" +
						   "Cálculadroa de IMC\n" +
						   "------------------\n" +
						   "Nombre: ");
		String name = in.next();
		
		System.out.println("Peso en kilogramos: ");
		double weight = in.nextDouble();
		
		System.out.println("Altura en metros: ");
		double heigth = in.nextDouble();
		
		double imc = weight / heigth;
		
		calculateIMC(imc, name);
		
		in.close();
	}// End method main

// End class SecretariaSaludMunicipal

public static void calculateIMC(double imc, String name) {
	if (imc < 18.5) {
		System.out.println(name + ", su IMC es de " + imc + " y se encuentra en el rango de bajo peso.");
	} else if (imc >= 18.5 && imc <= 24.9) {
		System.out.println(name + ", su IMC es de " + imc + " y se encuentra en el rango de sobrepeso.");
	} else if (imc >= 30.0) {
		System.out.println(name + ", su IMC es de " + imc + " y se encuentra en el rango de obesidad.");
	}
}}// End method calculateIMC
	

