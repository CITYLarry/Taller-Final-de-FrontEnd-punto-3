import java.util.Scanner;

public class DonCarlos {

	public static void main(String[] args) {
		
		int sales = 0;
		
		Scanner in = new Scanner(System.in);
		
		System.out.println("------------\n" +
						   "Nuevo pastel\n" +
						   "------------\n" +
						   "Nombre del cliente: ");
		String name = in.next();
		
		System.out.println("Sabor del pastel: ");
		String flavor = in.next();
		
		System.out.println("Cantidad de porciones: ");
		int size = in.nextInt();
		
		System.out.println("Tipo de decoraciones: ");
		String decorations = in.next();
		
		System.out.println("\nSeñor(a) " + name +
						   "\nPastel de sabor " + flavor +
						   "\nde " + size + " porciones\n" +
						   "con decoraciones " + decorations);
		confirmationProcess(in, sales);
		
		in.close();
	}// End method main 
public static int confirmationProcess(Scanner in, int sales){
	System.out.println("Desea conformar el pedido? (y/n)");
	String confirmation = in.next();
	if (confirmation.equals("y")) {
		sales = sales += 1;
		System.out.println(sales + " ordenes creadas hoy.");
	} else {
		System.out.println("Pedido cancelado.");
	}// End if else
	return sales;
}// End method confimationProces
	
}// End class DonCarlos
