import java.util.Scanner;

public class NombreApellido {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		System.out.println("Escriba su nombre: ");
		String firstName = sc.next();

		System.out.println("Escriba su apellido: ");
		String lastName = sc.next();

		sc.close();

	}// End main method

}// End class NombreApellido
