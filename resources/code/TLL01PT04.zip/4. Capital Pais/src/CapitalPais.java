import java.util.Scanner;

public class CapitalPais {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Escriba el nombre del país: ");
		String country = sc.next();

		System.out.println("Escriba la capital del país: ");
		String capitalCity = sc.next();

		sc.close();
		
		System.out.println("La ciudad " + capitalCity + 
						   ", es la capital del país " + country + ".");

	}// End method main

}// End class CapitalPais
