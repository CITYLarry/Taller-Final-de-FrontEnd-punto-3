import java.util.Scanner;

public class VideoShop {

	public static void main(String[] args) {

		// Variables
		String name;
		String moovie;
		String comments;

		// Prints the menu
		System.out.println("¿Qué desea hacer?\n" + 
						   "1. Consultar peliculas disponibles.\n" + 
						   "2. Alquilar pelicula.\n" + 
						   "3. Devolver pelicula.\n" + 
						   "4. Salir.\n");
		Scanner in = new Scanner(System.in);
		int option = in.nextInt();

		// Execute the menu option

		switch (option) {
		case 1: {
			System.out.println("Avenger (2012.\n" + 
							   "Forrest Gump.\n" + 
							   "Her.\n" + 
							   "Kung Fu Panda.\n" + 
							   "Proyecto X.\n" + 
							   "The Internship.\n");
			break;
		} // End case 1
		case 2: {
			System.out.println("Nombre completo del usuario: ");
			name = in.next();
			System.out.println("Nombre de la pelicula a alquilar: ");
			moovie = in.next();
			break;
		} // End case 2
		case 3: {
			System.out.println("Nombre completo del usuario: ");
			name = in.next();
			System.out.println("Nombre de la pelicula a devolver: ");
			moovie = in.next();
			System.out.println("Comentarios: ");
			comments = in.next();
			break;
		} // End case 3
		case 4: {
			System.out.println("Hasta luego, vuelva pronto.");
			break;
		} // End case 4
		default:
			System.out.println("Opcion invalida: " + option);
		}// End case default

		in.close();

	}// End method main

}// End class VideoShop
