import java.util.Scanner;

public class NombresMadrePadre {
	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		System.out.println("Escriba su nombre: ");
		String firstName = sc.next();

		System.out.println("Escriba su apellido: ");
		String lastName = sc.next();
		
		System.out.println("Escriba el nombre de su madre: ");
		String motherName = sc.next();

		System.out.println("Escriba el apellido de su madre: ");
		String motherLastName = sc.next();
		
		System.out.println("Escriba el nombre de su padre: ");
		String fatherName = sc.next();

		System.out.println("Escriba el apellido de su padre: ");
		String fatherLastName = sc.next();
		
		sc.close();
		
		System.out.println("Yo " + firstName + " " + lastName + 
						   ", soy hijo de " + motherName + " y " +
						   fatherName + ".");

	}// End main method

}// End class NombresMadrePadre
