import java.util.Scanner;

public class ElMaestro {

	public static void main(String[] args) {
		
		boolean exit = false;
		
		Alumno estudiantes[] = new Alumno[8];
		
		Scanner in = new Scanner(System.in);
		
		do {
			System.out.println("----------------------------------\n" +
					   		   "Escuela automovilistica El Maestro\n" +
					   		   "----------------------------------\n" +
					   		   "1. Ingresar estudiantes.\n" +
					   		   "2. Consultar resultado de estudiantes.\n" +
					   		   "3. Salir.\n");
			int option = in.nextInt();
			
			switch(option) {
				case 1:{
					System.out.println("--------------------\n" +
									   "Ingresar estudiantes\n" +
									   "--------------------\n");
					for (int i = 0; i < estudiantes.length; i++) {
						System.out.println("Estudiante " + (i+1) + ": \n");
						estudiantes[i] = ingresarAlumno(in);
						approvedCheck(estudiantes, i);
					}// End for
					break;
				}// End case 1
				case 2:{
					System.out.println("----------------------------------\n" +
									   "Consultar resultado de estudiantes\n" +
							   		   "----------------------------------\n");
					for (int i = 0; i < estudiantes.length; i++) {
						System.out.print((i+1) + ". " + estudiantes[i].getName() + ", ");
						if (estudiantes[i].isApproved() == true) {
							System.out.print("Aprobado\n");
						}else
							System.out.print("Reprobado\n");
						// End ifelse
					}// End for
					break;
				}// End case 2
				case 3:{
					exit = true;
					System.out.println("Adios!\n");
					break;
				}// End case 3
				default :{
					System.out.println("Opción invalida");
					break;
				}// End default
			}// End switch
		} while (exit == false);
		in.close();
		// End dowhile
	}// End method main
	
	public static Alumno ingresarAlumno(Scanner in) {
		
		System.out.println("Nombre: ");
		String name = in.next();
		System.out.println("Puntaje: ");
		int points = in.nextInt();
		
				
		Alumno estudiante = new Alumno(name, points);
				
		return estudiante;
	}// End method ingresar alumno
	
	public static void approvedCheck( Alumno estudiantes[], int i) {
		if (estudiantes[i].getPoints() > 97) {
			estudiantes[i].setApproved(true);
		}// End if
	}// 
}// End class ElMaestro
