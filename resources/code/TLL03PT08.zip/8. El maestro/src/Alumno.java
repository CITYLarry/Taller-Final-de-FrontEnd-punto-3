
public class Alumno {
	
	//Instance variables
	private String name;
	private int points;
	private boolean approved = false;
	
	public Alumno(String name, int points) {
		this.name = name;
		this.points = points;
	}// End constructor

	public String getName() {
		return name;
	}// End method getName
	public void setName(String name) {
		this.name = name;
	}// End method setName

	public int getPoints() {
		return points;
	}// End method getPoints

	public void setPoints(int points) {
		this.points = points;
	}// End method setPoints

	public boolean isApproved() {
		return approved;
	}// End method isApproved

	public void setApproved(boolean approved) {
		this.approved = approved;
	}// End method setApptoved
	
}// End class Alumno
