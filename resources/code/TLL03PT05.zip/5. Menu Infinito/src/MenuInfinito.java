import java.util.Scanner;

public class MenuInfinito {

	public static void main(String[] args) {
		
		boolean exit = false;
		Scanner in = new Scanner(System.in);
		do {
			System.out.println("---------------\n" +
							   "Menu de usuario\n" +
							   "---------------\n" +
							   "1. Capturar nombre.\n" +
							   "2. Saludar persona.\n" +
							   "3. Salir del sistema\n");
			int option = in.nextInt();
			
			
			if (option == 3) {
				exit = true;
				System.out.println("Adios!");
			}// End if
		} while (exit == false);
		//End do while
		in.close();
	}// End method main

}// End class MenuInfinito
