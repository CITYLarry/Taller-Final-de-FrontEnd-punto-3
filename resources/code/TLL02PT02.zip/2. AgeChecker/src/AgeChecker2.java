import java.util.Scanner;

public class AgeChecker2 {
	
	public static void main(String[] args) {
		
		Scanner in = new Scanner(System.in);
		
		System.out.println("Escriba su edad: ");
		int age = in.nextInt();
		
		in.close();
		
		if (age < 18) {
			System.out.println("Usted es un niño(a)");
		}

	}// End method main

}// End class AgeChecker
