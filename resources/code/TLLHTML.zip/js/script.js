
const toggleTheme1 = () => {
    document.documentElement.setAttribute('data-theme', 'theme1');
    localStorage.setItem('theme', 'theme1')
}

const toggleTheme2 = () => {
    document.documentElement.setAttribute('data-theme', 'theme2');
    localStorage.setItem('theme', 'theme2')
}

const toggleTheme3 = () => {
    document.documentElement.setAttribute('data-theme', 'theme3');
    localStorage.setItem('theme', 'theme3')
}

const currentTheme = localStorage.getItem('theme');
if (currentTheme === 'theme1') {
    toggleTheme1();
} else if (currentTheme === 'theme2') {
    toggleTheme2();
} else if (currentTheme === 'theme3') {
    toggleTheme3();
}

const main = ()=>{

    var btnList = document.querySelectorAll(".list .list-btn");

    for (let i = 0; i < btnList.length; i++) {
        btnList[i].addEventListener("click", function (e) {
            
            let btn = e.target;

            if(btn.className === "list-btn hidden"){
                btn.classList.remove("hidden")
            } else {
                btn.classList.add("hidden");
            }
                
        })
    }
}


