
public class CicloHastaQue {

	public static void main(String[] args) {
		int i = 0;
		int j = 10;
		String a = "           ";
		String b = "*";
		
		
		do {
			System.out.print(a);
			a = a.substring(0, j);
			System.out.println(b);
			b = b + "**";
			i++;
			j--;
		} while (i < 11);
		// End dowhile
		System.out.println("          ***\n" +
						   "          ***\n" +
						   "         *****\n" +
						   "        *******\n");
	}// End method main

}// End class CicloHastaQue
