
public class ParImpar {

	public static void main(String[] args) {
		
		int arr[] = new int[20];
		
		for (int i = 0; i < arr.length; i++) {
			arr[i] = (int) (Math.random() * 100 + 1);
		}// End for
		
		System.out.print("Numeros pares: ");
		for (int i = 0; i < arr.length; i++) {
			if (arr[i] % 2 == 0) {
				System.out.print(arr[i] + ", ");
			}// End if
		}// End for
		System.out.println();
		
		System.out.print("Numeros impares: ");
		for (int i = 0; i < arr.length; i++) {
			if (arr[i] % 2 != 0) {
				System.out.print(arr[i] + ", ");
			}// End if
		}// End for
		System.out.println();
	}// End method main
}// End class ParImpar
