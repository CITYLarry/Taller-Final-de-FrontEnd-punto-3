
public class Contacto {
	
	// Instance variables
	private String name;
	private String telephone;
	private String org;
	
	//Constructor
	public Contacto(String name, String telephone, String org) {
		this.name = name;
		this.telephone = telephone;
		this.org = org;
	}// End constructor

	public String getName() {
		return name;
	}// End method getName

	public void setName(String name) {
		this.name = name;
	}// End method setName

	public String getTelephone() {
		return telephone;
	}// End method getTlephone

	public void setTelephone(String telephone) {
		this.telephone = telephone;
	}// End method setTelephone

	public String getOrg() {
		return org;
	}// End method getOrg

	public void setOrg(String org) {
		this.org = org;
	}// End method setOrg
	
}// End class Contacto
