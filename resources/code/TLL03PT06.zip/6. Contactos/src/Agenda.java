import java.util.Scanner;

public class Agenda {

	public static void main(String[] args) {
		
		// Variables
		boolean exit = false;
		Contacto agenda[] = new Contacto[3];
		
		Scanner in = new Scanner(System.in);
		
		do {
			System.out.println("------\n" +
							   "Agenda\n" +
							   "------\n" +
							   "1. Añadir contactos.\n" +
							   "2. Buscar contacto.\n" +
							   "3. Eliminar contacto.\n" +
							   "4. Salir.\n");
			int option = in.nextInt();
			
			switch (option) {
				case 1:{
					System.out.println("----------------\n" +
									   "Añadir contactos\n" +
									   "----------------\n" +
									   "Contacto 1: ");
					agenda[0] = añadirContacto(in);
					System.out.println("Contacto 2: ");
					agenda[1] = añadirContacto(in);
					if ((agenda[0].getTelephone()).equals(agenda[1].getTelephone())) {
						eliminarContacto(1, agenda);
						System.out.println("El contacto ya existe");
						break;
					}// End if
					System.out.println("Contacto 3: ");
					agenda[2] = añadirContacto(in);
					if ((agenda[0].getTelephone()).equals(agenda[2].getTelephone()) || (agenda[1].getTelephone()).equals(agenda[2].getTelephone())) {
						eliminarContacto(1, agenda);
						System.out.println("El contacto ya existe");
						break;
					}// End if
					break;
				}// End case 1
				case 2:{
					System.out.println("---------\n" +
									   "Contactos\n" +
									   "---------\n" +
									   agenda[0].getName() + " " + agenda[0].getOrg() + "\n" +
									   agenda[0].getTelephone() +
									   "\n-----------------\n" +
									   agenda[1].getName() + " " + agenda[1].getOrg() + "\n" +
									   agenda[1].getTelephone() +
									   "\n-----------------\n" +
									   agenda[2].getName() + " " + agenda[2].getOrg() + "\n" +
									   agenda[2].getTelephone() +
									   "\n-----------------\n");
					break;
				}// End case 2
				case 3:{
					System.out.println("-----------------\n" +
							   		   "Elimniar contacto\n" +
							   		   "-----------------\n" +
							   		   "1. " + agenda[0].getName() + ".\n" +
							   		   "2. " + agenda[1].getName() + ".\n" +
							   		   "3. " + agenda[2].getName() + ".\n" +
							   		   "4. Salir.\n");
					int option2 = in.nextInt();
					switch (option2) {
						case 1:{
							eliminarContacto(0, agenda);
							System.out.println("Contacto eliminado.");
							break;
						}// End case 1
						case 2:{
							eliminarContacto(1, agenda);
							System.out.println("Contacto eliminado.");
							break;
						}// End case 2
						case 3:{
							eliminarContacto(2, agenda);
							System.out.println("Contacto eliminado.");
							break;
						}// End case 3
						case 4:{
							System.out.println("Canclado.\n");
							continue;
						}// End case 4
						default :{
							System.out.println("Opción invalida");
							break;
						}// End default
					}// End switch
				}// End case 3
				case 4:{
					exit = true;
					System.out.println("Adios!");
					break;
				}// End case 4
				default :{
					System.out.println("Opción invalida");
					break;
				}// End default
			}// End switch
			
		} while (exit == false);
		//End dowhile
		in.close();
	}// End method main

	public static Contacto añadirContacto(Scanner in) {
		
		System.out.println("Nombre: ");
		String name = in.next();
		System.out.println("Telefono: ");
		String telephone = in.next();
		System.out.println("Organización: ");
		String org = in.next();
		
		Contacto contacto = new Contacto(name, telephone, org);
		
		return contacto;
	}// End method añadir contacto
	
	public static void eliminarContacto(int i, Contacto agenda[]) {
		
		agenda[i].setName(null);
		agenda[i].setTelephone(null);
		agenda[i].setOrg(null);
	
	}// End method eliminarContacto
	
}// End class Agenda
