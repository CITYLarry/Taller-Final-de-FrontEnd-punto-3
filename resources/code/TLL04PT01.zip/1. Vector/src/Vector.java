import java.util.Scanner;

public class Vector {

	public static void main(String[] args) {
		
		Scanner in = new Scanner(System.in);
		
		int arr[] = new int[5];
		
		for (int i = 0; i < arr.length; i++) {
			System.out.println("Escriba un número para la posicion " + i + ".");
			arr[i] = in.nextInt();
		}// End for
		in.close();

		for (int i = 0; i < arr.length; i++) {
			System.out.println("[" + i + "] = " + arr[i]);
		}// End for
		
	}// End method main

}// End class Vector
