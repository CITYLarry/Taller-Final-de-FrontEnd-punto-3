
public class Vehiculo {
	
	// Instance variables
	private String plate;
	private String model;
	private String owner;
	private String telephone;
		
	public Vehiculo(String plate, String model, String owner, String telephone) {
		this.plate = plate;
		this.model = model;
		this.owner = owner;
		this.telephone = telephone;
	}// End constructor

	public String getPlate() {
		return plate;
	}// End method getPlate

	public void setPlate(String plate) {
		this.plate = plate;
	}// End method setPlate

	public String getModel() {
		return model;
	}// End method getModel

	public void setModel(String model) {
		this.model = model;
	}// End method setModel

	public String getOwner() {
		return owner;
	}// End method getOwner

	public void setOwner(String owner) {
		this.owner = owner;
	}// End method setOwner

	public String getTelephone() {
		return telephone;
	}// End methos getTelephone
	
	public void setTelephone(String telephone) {
		this.telephone = telephone;
	}// End methos setTelephone
		
}// End class Vehiculo
