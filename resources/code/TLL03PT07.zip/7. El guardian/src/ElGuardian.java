import java.util.Scanner;

public class ElGuardian {

	public static void main(String[] args) {
		
		// Variables
		boolean exit = false;
		Vehiculo vehiculos[] = new Vehiculo[5];
				
		Scanner in = new Scanner(System.in);
				
		do {
			System.out.println("-----------------------\n" +
							   "Parqueadero El Guardian\n" +
							   "-----------------------\n" +
							   "1. Ingresar vehiculo.\n" +
							   "2. Retirar vehiculo.\n" +
							   "3. Consultar vehiculo.\n" +
							   "4. Salir.\n");
			int option = in.nextInt();
					
				switch (option) {
					case 1:{
						System.out.println("----------------\n" +
										   "Ingresar Vehiculo\n" +
										   "----------------\n");
						
						for (int i = 0; i < vehiculos.length; i++) {
							System.out.println("Vehiculo " + (i+1) + ": \n");
							vehiculos[i] = ingresarVehiculo(in);
						}// End for
						break;
					}// End case 1
					case 2:{
						System.out.println("-----------------\n" +
										   "Elimniar contacto\n" +
										   "-----------------\n");
						for (int i = 0; i < vehiculos.length; i++) {
							System.out.println((i+1) + ". " + vehiculos[i].getModel() + ", " + vehiculos[i].getPlate() + ".\n");
						}// End for
						System.out.println("6. Cancelar.\n");		   
						int option2 = in.nextInt();
						
						switch (option2) {
						case 1:{
							retirarVehiculo(0, vehiculos);
							break;
						}// End case 1
						case 2:{
							retirarVehiculo(1, vehiculos);
							break;
						}// End case 2
						case 3:{
							retirarVehiculo(2, vehiculos);
							break;
						}// End case 3
						case 4:{
							retirarVehiculo(3, vehiculos);
							break;
						}// End case 4
						case 5:{
							retirarVehiculo(4, vehiculos);
							break;
						}// End case 5
						case 6:{
							System.out.println("Cancelado.\n");
							continue;
						}// End case 6
						default :{
							System.out.println("Opción invalida");
							break;
						}// End default
						}// End switch
						break;
					}// End case 2
					case 3:{
						System.out.println("------------------\n" +
										   "Consultar Vehiculo\n" +
										   "------------------\n" +
										   "Escriba la placa de su vehiculo: \n");
						String compare = in.next();
						
						if (vehiculos[0].getPlate().equals(compare) ||
							vehiculos[1].getPlate().equals(compare) ||
							vehiculos[2].getPlate().equals(compare) ||
							vehiculos[3].getPlate().equals(compare) ||
							vehiculos[4].getPlate().equals(compare)) {
							System.out.println("Su vehiculo está seguro en el parqueadero.");
						}else
							System.out.println("Su vehiculo no se encuentra en las instalaciones.");
						// End ifelse
						break;
					}// End case 3
					case 4:{
						exit = true;
						System.out.println("Adios!");
						break;
					}// End case 4
					default :{
						System.out.println("Opción invalida");
						break;
					}// End default
			}// End switch
					
		} while (exit == false);
		//End dowhile
		in.close();

	}// End method main

	public static Vehiculo ingresarVehiculo(Scanner in) {
				
		System.out.println("Placa: ");
		String plate = in.next();
		System.out.println("Modelo: ");
		String model = in.next();
		System.out.println("Nombre del propietario: ");
		String owner = in.next();
		System.out.println("Telefono: ");
		String telephone = in.next();
				
		Vehiculo vehiculos = new Vehiculo(plate, model, owner, telephone);
				
		return vehiculos;
	}// End method ingresarVehiculo
			
	public static void retirarVehiculo(int i, Vehiculo vehiculos[]) {
				
		vehiculos[i].setPlate(null);
		vehiculos[i].setModel(null);
		vehiculos[i].setOwner(null);
		vehiculos[i].setTelephone(null);
		
		System.out.println("Vehiculo retirado con exito");
		
	}// End method eliminarContacto

}// End class ElGuardian
