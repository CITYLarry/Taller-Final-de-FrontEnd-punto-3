import java.util.Scanner;

public class ElMaquinista {

	public static void main(String[] args) {
		
		Scanner in = new Scanner(System.in);
		
		// Prints the menu
		System.out.println("------------------------------\n" +
						   "Seleccione una opcion del menú\n" +
						   "------------------------------\n" +
						   "1. Ingreso de vehiculo.\n" + 
						   "2. Salida de vehiculo.\n" + 
						   "3. Salir.\n");
		int option = in.nextInt();
		
		switch(option) {
		case 1:{
			System.out.println("-------------------\n" +
					   		   "Ingreso de vehiculo\n" +
					   		   "-------------------\n");
			getCustomer(in);
			getCustomerID(in);
			getPlate(in);
			
			System.out.println("Observaciones: ");
			String commnets = in.next();
			break;
		}// End case 1
		case 2:{
			System.out.println("------------------\n" +
					   		   "Salida de vehiculo\n" +
					   		   "------------------\n");
			getCustomer(in);
			getCustomerID(in);
			getPlate(in);
			
			System.out.println("Novedades presentadas: ");
			String issues = in.next();
			
			System.out.println("Arreglos efectuados: ");
			String fixes = in.next();
			break;
		}// End case 2
		case 3:{
			System.out.println("Hasta luego, cuelca pronto!.");
			break;
		}// End case 3
		default:
			System.out.println("Opción invalida.");
			break;
		}// End switch
		
		in.close();
	}// End method main

public static String getCustomer(Scanner in) {
	System.out.println("Escriba el nombre del cliente: ");
	String customer = in.next();
	return customer;
}// End method getCustomer

public static String getCustomerID(Scanner in) {
	System.out.println("Cedula del cliente: ");
	String customerID = in.next();
	return customerID;
}// End method getCustomerID
	
public static String getPlate(Scanner in) {
	System.out.println("Placa del vehiculo: ");
	String plate = in.next();
	return plate;
}// End method plate

}// End class ELMaquinista
